package stepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HttpsURLConnection;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import Utility.*;




public class IPrice extends  MyUtils{
	List<WebElement> storesDetails,trendingProducts,topStores = null;
	String homePage = "https://iprice.my/";
	String url = "";
	HttpURLConnection huc = null;
	int respCode = 200;
	
	
	@Given("Go to Iprice Group Malaysia Website")
	public void go_to_iprice_group_malaysia_website() throws Exception {
		LaunchBrowser("https://iprice.my/");
		System.out.println("IPrice Group malaysia website opened successfully");
	}

	@When("Grab the list of stores in the Find the Best Deals Online")
	public void grab_the_list_of_stores_in_the_find_the_best_deals_online() throws Exception {
		storesDetails = gettingWebElementsfromList(By.xpath("//div[@class='tc kH']"));
		for(WebElement StoreName : storesDetails ) {
			System.out.println("List of Stores : " + StoreName.getText() );
			
		}
	}

	@When("Count the list of the stores in the Find the Best Deals Online")
	public void count_the_list_of_the_stores_in_the_find_the_best_deals_online(){
	   System.out.println("Count of the Stores under Find the best deals online section "  + storesDetails.size());
	}

	@When("Count the list of items in Top Trending Products")
	public void count_the_list_of_items_in_top_trending_products() throws Exception {
		trendingProducts = gettingWebElementsfromList(By.xpath("//a[@data-vars-cgt=\"click_trending_category_carousel_label\"]/span"));
		 System.out.println("Count of the Trending Products : "  + trendingProducts.size());
		for(WebElement productName : trendingProducts ) {
			System.out.println("List of TrendingProducts : " + productName.getText() );
			
		}
	}

	@Then("Validate that each item in Top Trending Products contains data-vars-cgt")
	public void validate_that_each_item_in_top_trending_products_contains_data_vars_cgt()throws Exception {
		trendingProducts = gettingWebElementsfromList(By.xpath("//a[@data-vars-cgt=\"click_trending_category_carousel_label\"]/span"));
		for(WebElement productName : trendingProducts ) {
		isAttribtuePresent(productName, "data-vars-cgt");
			System.out.println(productName.getText() + " contains data-vars-cgt attribute ");
		
		}}
	
	
	@Given("Go to Iprice Coupons Malaysia Website")
	public void go_to_iprice_coupons_malaysia_website() throws Exception {
		LaunchBrowser("https://iprice.my/coupons/");
		System.out.println("IPrice Coupons malaysia website opened successfully");
	}

	@When("Make sure that url of stores in Top Stores are all active")
	public void make_sure_that_url_of_stores_in_top_stores_are_all_active() throws Exception {
		topStores = gettingWebElementsfromList(By.xpath("//div[@data-vars-cgt='click_coupon_top_stores_item']/a"));
		Iterator<WebElement> it = topStores.iterator();

		while(it.hasNext()){

		url = it.next().getAttribute("href");

		System.out.println(url);

		if(url == null || url.isEmpty()){
		System.out.println("URL is either not configured for anchor tag or it is empty");
		continue;
		}

		if(!url.startsWith(homePage)){
		System.out.println("URL belongs to IPrice Group domain");
		continue;
		}

		try {
		huc = (HttpsURLConnection)(new URL(url).openConnection());

		huc.setRequestMethod("HEAD");

		huc.connect();

		respCode = huc.getResponseCode();
//		System.out.println(respCode);
		
		

		if(respCode >= 404){
		System.out.println(url+" is a broken link");
		}
		else{
		System.out.println(url+" is a valid link");
		}

		} catch (MalformedURLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		}

	}

	@Then("Validate list of stores in Top Stores is redirected to their proper store url")
	public void validate_list_of_stores_in_top_stores_is_redirected_to_their_proper_store_url() throws Exception {
		
		topStores = gettingWebElementsfromList(By.xpath("//div[@data-vars-cgt='click_coupon_top_stores_item']/a"));
		
		for (int i =1 ;i <= topStores.size();i++) {
			String StoreName = driver.findElement(By.xpath("(//div[@data-vars-cgt='click_coupon_top_stores_item']/a)["+i+"]")).getAttribute("href");
			System.out.println(StoreName);
			driver.get(StoreName);
			String currentUrl = driver.getCurrentUrl();
			System.out.println(currentUrl);
			Assert.assertEquals(currentUrl, StoreName);
			System.out.println("User Navigated to correct url");
			driver.get("https://iprice.my/coupons/");
			Thread.sleep(4000);
		}
//		for(WebElement Storelink : topStores ) {
//			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
//			
//			String StoreName = Storelink.getAttribute("href");
//			System.out.println(StoreName);
//			driver.get(StoreName);
////			Storelink.click();
//			String currentUrl = driver.getCurrentUrl();
//			System.out.println(currentUrl);
//			Assert.assertEquals(currentUrl, StoreName);
//			System.out.println("User Navigated to correct url");
//			driver.get("https://iprice.my/coupons/");
//			
//		} 
	}
	
	
}
